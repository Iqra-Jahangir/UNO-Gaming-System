package uno;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*; // Assuming DBConnection and database logic are handled elsewhere

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JRadioButton rememberMeRadio;
    private JMenuBar menuBar;

    public LoginForm() {
        setTitle("UNO Game Login");
        // Adjust the size to better match the screenshot
        setSize(500, 350); // Increased width and height
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // Use a more flexible layout for the main content panel
        setLayout(new BorderLayout());

        // --- Menu Bar ---
        menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0)); // Exit on click
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // --- Main Content Panel using GridBagLayout for better control ---
        JPanel contentPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20); // Padding around components

        // Username Label and Field
        usernameField = new JTextField(20); // Set preferred column size for better visual
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the west
        contentPanel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Make field expand horizontally
        contentPanel.add(usernameField, gbc);

        // Password Label and Field
        passwordField = new JPasswordField(20); // Set preferred column size
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.NONE; // Reset fill for label
        contentPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(passwordField, gbc);

        // Remember Me Radio Button
        rememberMeRadio = new JRadioButton("Remember Me");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.NONE;
        contentPanel.add(rememberMeRadio, gbc);

        // Add the main content panel to the CENTER of the JFrame's BorderLayout
        add(contentPanel, BorderLayout.CENTER);

        // --- Button Panel ---
        // Create a sub-panel for the buttons to place them side-by-side
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Center buttons with spacing
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        // Add the button panel to the SOUTH of the JFrame's BorderLayout
        add(buttonPanel, BorderLayout.SOUTH);

        // --- Button Listeners ---
        loginButton.addActionListener(e -> login());
        registerButton.addActionListener(e -> register());

        // Center the window on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                // TODO: Move to game screen
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void register() {
        // Placeholder for future register form
        JOptionPane.showMessageDialog(this, "Register button clicked!");
        // TODO: Open registration form
    }

    public static void main(String[] args) {
        // Ensure that Swing components are created and updated on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new LoginForm());
    }
}

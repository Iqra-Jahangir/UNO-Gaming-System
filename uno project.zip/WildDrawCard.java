package uno;

/**
 * This class represents a Wild Draw 4 card in UNO game.
 * It extends from {@code Card} class.
 */
public class WildDrawCard extends Card {

    /**
     * Create a new Wild Draw card with the given card code.
     * Wild draw cards are always black.
     *
     * @param cardCode the code number of the card
     */
    public WildDrawCard(int cardCode) {
        super(20, Color.BLACK, cardCode);
    }

    /**
     * This method returns a string representing the visual line of the card.
     * If the lineNumber is negative, it calls the parent class toString().
     *
     * @param lineNumber the number of the card line
     * @return visual representation string
     */
    @Override
    public String toString(int lineNumber) {
        if (lineNumber < 0)
            return super.toString(-lineNumber);

        switch (lineNumber) {
            case 1:
            case 7:
                return Color.getColorCodeString(Color.WHITE) + "•~~~~~~~•" + Color.getColorCodeString(Color.RESET);
            case 2:
                return Color.getColorCodeString(Color.WHITE) + "|+4     |" + Color.getColorCodeString(Color.RESET);
            case 3:
            case 5:
                return Color.getColorCodeString(Color.WHITE) + "|       |" + Color.getColorCodeString(Color.RESET);
            case 4:
                return Color.getColorCodeString(Color.WHITE) + "|" +
                        Color.getColorCodeString(Color.RED) + "W " +
                        Color.getColorCodeString(Color.YELLOW) + "i " +
                        Color.getColorCodeString(Color.GREEN) + "l " +
                        Color.getColorCodeString(Color.BLUE) + "d" +
                        Color.getColorCodeString(Color.WHITE) + "|" +
                        Color.getColorCodeString(Color.RESET);
            case 6:
                return Color.getColorCodeString(Color.WHITE) + "|     +4|" + Color.getColorCodeString(Color.RESET);
            case 8:
                return Color.getColorCodeString(Color.WHITE) + "code: " + super.getCardCode() +
                        Color.getColorCodeString(Color.RESET);
        }
        return null;
    }
}
